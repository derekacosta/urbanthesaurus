from setuptools import setup

setup(
    name="urban",
    version="1.0",
    install_requires=[
        "requests",
    ],
)
